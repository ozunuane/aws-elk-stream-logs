Modify Logstash input to Aws setting 
 
Run docker build . -t "logstash/aws" 


